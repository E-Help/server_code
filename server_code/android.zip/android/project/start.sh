#!/bin/bash
nohup python ehelp_main.py >/dev/null 2>&1 &
