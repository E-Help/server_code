#!/bin/bash
pkill -9 -f ehelp_main.py
