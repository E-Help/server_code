#!/usr/python

# http response
OK = 200
ERROR = 500

# static relation
REFUSE = 0
AGREE = 1
WAITING = 2

# event status
EVENT_CARRYING = 0
EVENT_CANCELED = 1
EVENT_ENDED = 2

