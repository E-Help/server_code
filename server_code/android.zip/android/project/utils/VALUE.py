
'''control the incease of reputation'''
RATE = 0.25

default_coin = 5
reward_factor = 1
