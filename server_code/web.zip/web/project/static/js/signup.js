$(function() {
	$('.dropdown').dropdown({});
})
