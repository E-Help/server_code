#!/bin/bash
pkill -9 -f python
