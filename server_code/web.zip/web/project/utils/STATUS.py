#!/usr/python

# http response
OK = 200
ERROR = 500

# static relation
REFUSE = 0
AGREE = 1
WAITING = 2

