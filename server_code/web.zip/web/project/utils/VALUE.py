
'''control the incease of reputation'''
RATE = 0.25
